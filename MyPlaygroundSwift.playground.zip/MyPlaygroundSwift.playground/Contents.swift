import UIKit

// Типы данных
// Переменные
var greeting = "Hello, playground"
var test = 12
var test2: Int = 15
var res = 0

// Константы
let bounes: String = "Stive"

// String - строка
var name = "Stive"
		
// Character - Символы
var a = "a"

// Int
var age = 18

// Double
var temperature = 10.512322342234242342

// Float 6 чисел после запятой
var number: Float = 15.9

// Bool
var flagRes = true

// Convert
var sum = Float(age) + number
Int(number)
String(age)

var numStr = "10qwe"
var numInt = 20

var sumRes = numInt + (Int(numStr) ?? 0)


