import UIKit

// While циклы

var counter = 5

//while counter > 0 {
//    print("The counter is \(counter)")
//    counter -= 1
//}

repeat {
    print("The counter is \(counter)")
    counter -= 1
} while counter > 0
