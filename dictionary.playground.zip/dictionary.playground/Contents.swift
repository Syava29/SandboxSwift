import UIKit

// создание пустого словаря
var stringDictionary = Dictionary<String, String>()
var anotherStringDictionary:Dictionary<String, String> = [:]

var oneMoreDictionary = [Int: String]()
var phoneBook: [String: Int] = [:]

// наполнение словаря значениями
phoneBook = ["Andrey": 88002002121, "Maksim": 88003003131]

// изменение значений по ключу
phoneBook["Maksim"] = 900
//print(phoneBook)

// добавление пары ключ значение
phoneBook["Jack"] = 999
//print(phoneBook)

// удаление значения по ключу
phoneBook.removeValue(forKey: "Jack")
phoneBook["Jack"] = nil

// обнуление словаря
//phoneBook.removeAll()
//phoneBook = [:]

// свойство count и isEmpty
phoneBook.count
phoneBook.isEmpty

// обновить значение по ключу
let andreyOldNumber = phoneBook.updateValue(8800, forKey: "Andrey")
print(phoneBook)
