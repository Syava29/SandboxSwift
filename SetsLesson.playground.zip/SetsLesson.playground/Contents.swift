import UIKit

// создание пустого множества первый вариант предпочтительнее
var someStrings: Set<String> = []
var characters = Set<Character>()

// заполнение множества элементами
var strings: Set = ["B", "A", "D", "C", "E"]

// проверка содержания в множестве элемента
strings.contains("A")

// добавление нового элемента
strings.insert("D")
strings.insert("A")

// свойство isEmpty
if !strings.isEmpty {
    print("the set is not empty")
}

// удаление элементов
strings.remove("D")

// сортировка
strings.sorted()
// сортировка по убыванию
strings.sorted(by: >)

//объединение множеств
var newStrings: Set = ["A", "f", "g"]
let allStrings = strings.union(newStrings)

// пересечение множеств
let commonStrings = strings.intersection(newStrings)
