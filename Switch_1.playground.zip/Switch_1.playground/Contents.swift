import UIKit

var animals = "dove"

/*
if animals == "cat" {
    print("it's a cat")
} else if animals == "dog" {
    print("it's a dog")
} else if animals == "bird" {
    print("it's a bird")
} else {
    print ("I don't know this kind of animal")
}
*/

switch animals {
case "cat":
    print("it's a cat")
case "dog":
    print("it's a dog")
case "parrot", "dove", "sparrow", "bird":
    print("it's a bird")
default:
    print("I don't know this kind of animal")
}


let numberOfPeople = 5
var amount = ""

switch numberOfPeople {
case ..<0:
    print("it's impossible!")
case 0:
    amount = "No"
case 1:
    amount = "One"
case 2...5:
    amount = "Few"
case 6..<10:
    amount = "enough"
case 10...30:
    amount = "many"
default:
    amount = "too many"
}

print("\(amount) people came at my party")



