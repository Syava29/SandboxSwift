import UIKit

// String

let name = "Andrey"
let surname = "Sevostyanov"

// Конкатенация
var fullName = name + " " + surname
var hello = "Hello, "

hello += fullName

// интерполяция

let information = "Поезд отправится в 8:00"
let timeNow = "8:30"

let newInformation = "Поезд отправится в \(timeNow)"
//print(newInformation)

let a = 10
let b = 5
let infoAboutSum = "the sum of a and b is \(a + b)"
//print(infoAboutSum)

let newText =
"""
Свойства связывают значения с определённым классом, структурой или перечислением. Свойства хранения
содержат значения константы или переменной как часть экземпляра, в то время как вычисляемые свойства
вычисляют значения, а не хранят их.
"""
//print(newText)

