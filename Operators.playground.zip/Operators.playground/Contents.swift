import UIKit

// Operators

var number1 = 10
//print(number1)

var a = 5
var b = 3

// арифметические операторы
a + b
a - b
a * b
a / b

// Составные операторы
a += 1
a -= 1
a *= 2
a /= 2

// Остаток от деления
let d = 17 % 3


// Операторы сравнения
a = 10
b = 8

a > b
a < b
a >= b
a <= b
a != b
a == b

// Логические операторы

var time = 8
var temperature = 21

temperature >= 21 || time >= 30
temperature >= 21 && time >= 30

let answer = temperature >= 21 && time >= 30
//print (answer)
print(!answer)
