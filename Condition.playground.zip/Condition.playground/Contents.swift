import UIKit

var age = 18
var name: String = "Andrey"

if age > 18 {
    print("Доступ в систему разрешён, \(name)")
} else if age == 18 {
    print("Запросите доступ, \(name)")
} else {
    print("Доступ запрещён, \(name)")
}

// Составные условия && ||
if age >= 18 && name == "Andrey" {
    print("Добро пожаловать, \(name)")
} else if age < 18 && name == "Andrey" {
    print("Запросите доступ, \(name)")
} else {
    print("Доступ запрещён, \(name)")
}

// Тернарный оператор: condition ? first code : second code

age >= 18 ? print("Добро пожаловать, \(name)") : print("Отказано в доступе, \(name)")

let a = 5
var b = 0

if a < 5 {
    b = a + 5
} else {
    b = a - 5
}
    
b = a < 10 ? a + 5 : a - 5
print(b)
