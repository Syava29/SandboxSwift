import UIKit

// Создание массива
//let integers = [1, 2, 3, 4, 5]
var integers = [1, 2, 3, 4, 5]


// Создание пустого массива 2 варианта. 2 вариант используется чаще
var newIntegers = [Int]()
var numbers:[Int] = []

// добавление элементов
numbers = [1, 2, 3, 4, 5]
numbers += [6, 7, 8]

// добавление одного элемента
numbers.append(9)

// добавление по индексу
numbers.insert(10, at: 0)

// сложение массивов
let someIntegers = integers + numbers

// удаление элементов
let lastNumber = numbers.removeLast()
let firsNumber = numbers.removeFirst()

numbers.remove(at: 3)
//numbers.removeAll()
numbers = []

// количество элементов
integers.count

// обращение к элементу
integers[3]
integers[3] = 10
integers.reverse()
