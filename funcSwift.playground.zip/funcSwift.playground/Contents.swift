import UIKit

// функции

func tellAboutMe() {
    print("Hello, my name is Andrey")
}

tellAboutMe()

let doSomething = tellAboutMe
doSomething()


// функция с return
func tellMeSomething() -> String {
    //return "Hello, world"
    "Hello world"
}
tellMeSomething()

let greeting = tellMeSomething()
greeting

// функция с параметрами
func sayHello(name: String) -> String {
    //return "Hello \(name)"
    "Hello \(name)"
}

let hello = sayHello(name: "Andrey")

print(sayHello(name: "Andrey"))


func sayHelloNew(to myFriendName: String, from myName: String) -> String {
    "Hello, \(myFriendName). It's \(myName)!"
}

sayHelloNew(to: "Maksim", from: "Andrey")

func sayHello(_ myFriendName: String, _ myName: String) -> String {
    "Hello, \(myFriendName). It's \(myName)!"
}

sayHello("Andrey", "Maksim")

// вариативный параметр

func findSum(of numbers: Int...) -> Int {
    var sum = 0
    
    for number in numbers {
        sum += number
    }
        
    return sum
}

findSum(of: 1,2,3,4,5,6 )
