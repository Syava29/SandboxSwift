import UIKit

// кортежи или tuples

let first = 1
let second = 2
let third = 3

(first, second, third)

var person = ("Maksim", 25, "artist")
person.0
person.1

let (_, _, professional) = person

//name
//age
professional


let personOne = (name: "John", age: 30)
personOne.age


let (one, two, three) = (1, 2, 3)
one
two
three


let namesAndAges = ["John": 23, "Maksim": 28]

for (name, age) in namesAndAges {
    print("\(name) is \(age) years old")
}
