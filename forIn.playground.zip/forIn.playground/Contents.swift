import UIKit


// Цикл for in

//for number in 1...5 {
//    print(number)
//}

//for _ in 1...5 {
//    print("Hello")
//}

// иттерация по массиву
let animals = ["rabbit", "cow", "horse", "rabbit"]

var rabbitCount = 0

for animal in animals {
    if animal == "rabbit" {
        rabbitCount += 1
    }
}

print("At our farm there are \(rabbitCount) rabbits")

// иттерация по словарю

let familiesAndChildren = ["Jonsons": 4, "Simpsons": 3, "Jacksons": 6]

for (family, childrenCount) in familiesAndChildren {
    print("The \(family) have \(childrenCount) children")
}

for family in familiesAndChildren.keys {
    print("I don't like the \(family)")
}

for childrenCount in familiesAndChildren.values {
    print("I don't have \(childrenCount) children")
}

// иттерация по тексту
let text = "Hello, world!"

for character in text {
    print(character)
}

